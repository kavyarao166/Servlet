package com.space.empmgt.service;

import java.sql.SQLException;

import com.space.empmgt.model.EmpForm;

public interface EmpService {
	public void regEmp()throws SQLException;
	public void createEmp(EmpForm emp)throws SQLException;
	public void deleteEmp()throws SQLException;
	public void editEmp()throws SQLException;
	public void getEmpById()throws SQLException;
	public void getEmpByName()throws SQLException;
	public void getEmpByDesigination()throws SQLException;
	public void getEmpBySalary()throws SQLException;
	public void getAllEmps()throws SQLException;
}
