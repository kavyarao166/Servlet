package com.space.empmgt.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.space.empmgt.dao.EmpDaoImpl;
import com.space.empmgt.dao.EmployeeDao;
import com.space.empmgt.model.EmpForm;

public class EmpServiceImpl implements EmpService {

	EmployeeDao edao=new EmpDaoImpl();
	Scanner sc=new Scanner(System.in);

	@Override
	public void regEmp() throws SQLException {
			
		System.out.println("Enter the name");
		String name=sc.next();
		System.out.println("Enter the desigination");
		String desig=sc.next();
		System.out.println("Enter the salary");
		int salary=sc.nextInt();
		
		EmpForm emps=new EmpForm();
		emps.setEmp_name(name);
		emps.setEmp_desigination(desig);
		emps.setEmp_salary(salary);
		edao.regEmp(emps);
	}

	@Override
	public void deleteEmp() throws SQLException {
		System.out.println("Enter the Id which you want to delete");
		int id=sc.nextInt();
		EmpForm emp=new EmpForm();
		emp.setEmp_id(id);
		edao.deleteEmp(emp);
	}

	@Override
	public void editEmp() throws SQLException {
		System.out.println("Enter the Id which you want to update");
		int id=sc.nextInt();
		System.out.println("Enter the new name");
		String name=sc.next();
		System.out.println("Enter the new desigination");
		String desig=sc.next();
		System.out.println("Enter the new salary");
		int salary=sc.nextInt();
		
		EmpForm emp=new EmpForm();
		emp.setEmp_name(name);
		emp.setEmp_desigination(desig);
		emp.setEmp_salary(salary);
		edao.editEmp(emp);
	}

	@Override
	public void getEmpById() throws SQLException {
		System.out.println("Enter the Id which you want to List");
		int id=sc.nextInt();
		EmpForm emp=edao.getEmpById(id);
		System.out.println("ID\tName\tDesigination\tSalary");
		System.out.println(emp.getEmp_id()+"\t"+emp.getEmp_name()+"\t"+emp.getEmp_desigination()+"\t"+emp.getEmp_salary());
	}

	@Override
	public void getEmpByName() throws SQLException {
		System.out.println("Enter the name which you want to List");
		String name=sc.next();
		List <EmpForm> emps=edao.getEmpByName(name);
		System.out.println("ID\tName\tDesigination\tSalary");
		for(EmpForm emp:emps) {
			System.out.println(emp.getEmp_id()+"\t"+emp.getEmp_name()+"\t"+emp.getEmp_desigination()+"\t"+emp.getEmp_salary());
		}
	}

	@Override
	public void getEmpByDesigination() throws SQLException {
		System.out.println("Enter the desigination which you want to List");
		String desig=sc.next();
		List <EmpForm> emps=edao.getEmpByDesigination(desig);
		System.out.println("ID\tName\tDesigination\tSalary");
		for(EmpForm emp:emps) {
			System.out.println(emp.getEmp_id()+"\t"+emp.getEmp_name()+"\t"+emp.getEmp_desigination()+"\t"+emp.getEmp_salary());
		}
	}

	@Override
	public void getEmpBySalary() throws SQLException {
		System.out.println("Enter the salary which you want to List");
		int salary=sc.nextInt();
		List <EmpForm> emps=edao.getEmpBySalary(salary);
		System.out.println("ID\tName\tDesigination\tSalary");
		for(EmpForm emp:emps) {
			System.out.println(emp.getEmp_id()+"\t"+emp.getEmp_name()+"\t"+emp.getEmp_desigination()+"\t"+emp.getEmp_salary());
		}
	}

	@Override
	public void getAllEmps() throws SQLException {
		List <EmpForm> emps=edao.getAllEmps();
		System.out.println("ID\tName\tDesigination\tSalary");
		for(EmpForm emp:emps) {
			System.out.println(emp.getEmp_id()+"\t"+emp.getEmp_name()+"\t"+emp.getEmp_desigination()+"\t"+emp.getEmp_salary());
		}
	}

	@Override
	
	 public void createEmp(EmpForm emp) throws SQLException {
	 
	 edao.regEmp(emp); }
	

}
