package com.space.empmgt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbUtility {

	private static Connection con;
	static{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/newdb?user=root&password=root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public PreparedStatement createPST(String sql) throws SQLException {
		return con.prepareStatement(sql);
	}
	
	//This method will edit or update the database
	public int update(PreparedStatement pst) throws SQLException {
		return pst.executeUpdate();
	}
	
	//This method will fetch details the database
	public ResultSet query(PreparedStatement pst) throws SQLException {
		return pst.executeQuery();
	}
	
	public boolean testCon(){
		if(con!=null) {
			return true;
		}
		else {
			return false;
		}
	}

}
