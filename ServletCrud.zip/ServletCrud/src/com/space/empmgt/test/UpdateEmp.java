package com.space.empmgt.test;

import java.sql.SQLException;
import java.util.Scanner;

import com.space.empmgt.dao.EmpDaoImpl;
import com.space.empmgt.dao.EmployeeDao;
import com.space.empmgt.model.EmpForm;

public class UpdateEmp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		EmployeeDao dao=new EmpDaoImpl();
		System.out.println("Enter the Id which you want to update");
		int id=sc.nextInt();
		System.out.println("Enter the new name");
		String name=sc.next();
		System.out.println("Enter the new desigination");
		String desig=sc.next();
		System.out.println("Enter the new salary");
		int salary=sc.nextInt();
		
		EmpForm emp=new EmpForm();
		emp.setEmp_name(name);
		emp.setEmp_desigination(desig);
		emp.setEmp_salary(salary);
		
		try {
			int status=dao.editEmp(emp);
			if(status>0) {
				System.out.println("1 Value updated");
			}
			else {
				System.out.println("Error");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
