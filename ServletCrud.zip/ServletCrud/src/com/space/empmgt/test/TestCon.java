package com.space.empmgt.test;

import com.space.empmgt.db.DbUtility;

public class TestCon {

	public static void main(String[] args) {

		DbUtility dbu=new DbUtility();
		System.out.println(dbu.testCon());
	}

}
