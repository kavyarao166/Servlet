package com.space.empmgt.dao;

import java.sql.SQLException;
import java.util.List;

import com.space.empmgt.model.EmpForm;

public interface EmployeeDao {
	public int regEmp(EmpForm emp)throws SQLException;
	public int deleteEmp(EmpForm emp)throws SQLException;
	public int editEmp(EmpForm emp)throws SQLException;
	public EmpForm getEmpById(int id)throws SQLException;
	public List<EmpForm> getEmpByName(String name)throws SQLException;
	public List<EmpForm> getEmpByDesigination(String desig)throws SQLException;
	public List<EmpForm> getEmpBySalary(int salary)throws SQLException;
	public List<EmpForm> getAllEmps()throws SQLException;

	
}
