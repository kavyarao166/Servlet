package com.space.empmgt.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.space.empmgt.db.DbUtility;
import com.space.empmgt.model.EmpForm;

public class EmpDaoImpl implements EmployeeDao {
	DbUtility db=new DbUtility();
	PreparedStatement pst;
	ResultSet rs;

	@Override
	public int regEmp(EmpForm emp) throws SQLException {
		String sql="insert into empForm(emp_name,emp_desigination,emp_salary) values(?,?,?)";
		pst=db.createPST(sql);
		pst.setString(1, emp.getEmp_name());
		pst.setString(2, emp.getEmp_desigination());
		pst.setInt(3, emp.getEmp_salary());

		return db.update(pst);
	}

	@Override
	public int deleteEmp(EmpForm emp) throws SQLException{
		String sql="delete from empForm where emp_id=?";
		pst=db.createPST(sql);
		pst.setInt(1, emp.getEmp_id());
		return db.update(pst);
	}

	@Override
	public int editEmp(EmpForm emp) throws SQLException{
		String sql="update employee set emp_name=?,emp_desigination=?emp_salary=? where emp_id=?";
		pst=db.createPST(sql);
		pst.setString(1, emp.getEmp_name());
		pst.setString(2, emp.getEmp_desigination());
		pst.setInt(3, emp.getEmp_salary());
		return db.update(pst);
	}

	@Override
	public EmpForm getEmpById(int id) throws SQLException{
		String sql="select * from empForm where emp_id=?";
		pst=db.createPST(sql);
		pst.setInt(1, id);
		rs=db.query(pst);
		EmpForm emp=new EmpForm();
		if(rs.next()) {
			emp.setEmp_id(id);
			pst.setString(1, emp.getEmp_name());
			pst.setString(2, emp.getEmp_desigination());
			pst.setInt(3, emp.getEmp_salary());
		}
		return emp;
	}

	@Override
	public List<EmpForm> getEmpByName(String name)throws SQLException {
		String sql="select * from empForm where emp_name=?";
		pst=db.createPST(sql);
		pst.setString(1, name);
		rs=db.query(pst);
		List<EmpForm> emps= new ArrayList<EmpForm>();
		EmpForm emp=new EmpForm();
		if(rs.next()) {
			emp.setEmp_name(name);
			pst.setString(1, emp.getEmp_name());
			pst.setString(2, emp.getEmp_desigination());
			pst.setInt(3, emp.getEmp_salary());
			emps.add(emp);
		}
		return emps;

	}

	@Override
	public List<EmpForm> getEmpByDesigination(String desig)throws SQLException {
		String sql="select * from empForm where emp_desigination=?";
		pst=db.createPST(sql);
		pst.setString(1, desig);
		rs=db.query(pst);
		List<EmpForm> emps= new ArrayList<EmpForm>();
		EmpForm emp=new EmpForm();
		if(rs.next()) {
			emp.setEmp_desigination(desig);
			pst.setString(1, emp.getEmp_name());
			pst.setString(2, emp.getEmp_desigination());
			pst.setInt(3, emp.getEmp_salary());
			emps.add(emp);
		}
		return emps;
	}

	@Override
	public List<EmpForm> getEmpBySalary(int salary) throws SQLException{
		String sql="select * from empForm where emp_salary=?";
		pst=db.createPST(sql);
		pst.setInt(1, salary);
		rs=db.query(pst);
		List<EmpForm> emps= new ArrayList<EmpForm>();
		EmpForm emp=new EmpForm();
		if(rs.next()) {
			emp.setEmp_salary(salary);
			pst.setString(1, emp.getEmp_name());
			pst.setString(2, emp.getEmp_desigination());
			pst.setInt(3, emp.getEmp_salary());
			emps.add(emp);
		}
		return emps;
	}

	@Override
	public List<EmpForm> getAllEmps() throws SQLException{
		String sql="select * from empForm";
		pst=db.createPST(sql);
		rs=db.query(pst);
		List<EmpForm> emps= new ArrayList<EmpForm>();
		EmpForm emp=new EmpForm();
		if(rs.next()) {
			emp.setEmp_id(rs.getInt("id"));
			pst.setString(1, emp.getEmp_name());
			pst.setString(2, emp.getEmp_desigination());
			pst.setInt(3, emp.getEmp_salary());
			emps.add(emp);
		}
		return emps;
	}

}
