package com.space.empmgt.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.space.empmgt.service.EmpService;
import com.space.empmgt.service.EmpServiceImpl;

public class EmpMgmt {
	
	public static void main(String args[]) throws SQLException{
		boolean status=true;
		EmpService service=new EmpServiceImpl();
		while(status) {
		System.out.println("WELCOME TO EMPLOYEE MANAGEMENT SYSTEM");
		System.out.println("PRESS 1 TO REGISTER EMPLOYEE");
		System.out.println("PRESS 2 TO UPDATE EMPLOYEE");
		System.out.println("PRESS 3 TO DELETE EMPLOYEE");
		System.out.println("PRESS 4 TO GET EMPLOYEE BY ID");
		System.out.println("PRESS 5 TO GET EMPLOYEE BY NAME");
		System.out.println("PRESS 6 TO GET EMPLOYEE BY DESIGINATION");
		System.out.println("PRESS 7 TO GET EMPLOYEE BY SALARY");
		System.out.println("PRESS 8 TO GET ALL EMPLOYEES");
		System.out.println("PRESS 0 TO EXIT");
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR CHOICE");
		int choice=sc.nextInt();
		switch(choice) {
		case 1:service.regEmp();
			break;
		
		case 2:service.editEmp();
			break;
		case 3:service.deleteEmp();
		break;
		case 4:service.getEmpById();
		break;
		case 5:service.getEmpByName();
		break;
		case 6:service.getEmpByDesigination();
		break;
		case 7:service.getEmpBySalary();
		break;
		case 8:service.getAllEmps();
		break;
		case 0:System.out.println("WELCOME AGAIN");
			System.exit(0);
			break;
		default:System.out.println(" PLEASE ENTER THE CORRECT OPTION ");
			break;
		}

		
		
	}

}
}
