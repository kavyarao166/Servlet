package com.space.connection;

import java.util.*;
import java.sql.*;

public class ConnectionDb {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE EMPLOYEE NAME: ");
		String name=sc.next();
		System.out.println("ENTER THE EMPLOYEE DESIGINATION: ");
		String desig=sc.next();
		System.out.println("ENTER THE EMPLOYEE SALARY: ");
		int salary=sc.nextInt();
		
		//Load the driver class
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/newdb?user=root&password=root");
			String sql="insert into empform(emp_name,emp_desigination,emp_salary) values(?,?,?)";
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setString(1,name);
			pst.setString(2,desig);
			pst.setInt(3,salary);
			
			int status=pst.executeUpdate();
			if(status>0) {
				System.out.println("Values are inserted");
			}
			else {
				System.out.println("Error");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
