package com.space.connection;

import java.sql.*;

public class FetchRecord {
	
		public static void main(String[] args) {

			//Load the driver class
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Connection con;
			try {
				con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/newdb?user=root&password=root");
				String sql="select * from empForm";
				PreparedStatement pst= con.prepareStatement(sql);
				
				ResultSet rs=pst.executeQuery();
				System.out.println("ID\tName\tDesigination\tSalary");
				while(rs.next()) {
					System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getString("emp_desigination")+"\t\t"+rs.getInt("emp_salary"));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}
