package com.space.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.space.empmgt.model.EmpForm;
import com.space.empmgt.service.EmpService;
import com.space.empmgt.service.EmpServiceImpl;

/**
 * Servlet implementation class SaveEmp
 */
@WebServlet({ "/SaveEmp", "/saveEmp" })
public class SaveEmp extends HttpServlet {
	EmpService service=new EmpServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		EmpForm emp=new EmpForm();
		emp.setEmp_name(request.getParameter("name"));
		emp.setEmp_desigination((request.getParameter("desig")));
		try {
			service.createEmp(emp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		out.println("<h1>Data Inserted</h1>");
	}
}	
